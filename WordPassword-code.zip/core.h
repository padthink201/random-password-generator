#ifndef WPV_CORE_H
#define WPV_CORE_H
#include <stddef.h>
#include <stdint.h>

typedef struct {
    int words;
    int digits;
    int sep_mode;
    int caps_mode;
} GenOpts;

extern const char GEN_SEPS[];
double gen_password(const GenOpts *o, char *out, size_t cap);
const char *gen_strength(double bits);
void rand_bytes(void *buf, size_t n);

#define NAME_MAX_LEN 120
#define PASS_MAX_LEN 200

typedef struct {
    char name[NAME_MAX_LEN + 1];
    char pass[PASS_MAX_LEN + 1];
} Entry;

typedef struct {
    char     path[1024];
    uint8_t  key[32];
    uint8_t  salt[16];
    uint32_t nb_blocks, nb_passes;
    Entry   *items;
    int      count, cap;
    int      open;
} Vault;

enum { V_OK = 0, V_ERR_IO = -1, V_ERR_PASSWORD = -2, V_ERR_FORMAT = -3, V_ERR_MEM = -4 };

void        vault_default_path(char *out, size_t cap);
int         vault_exists(const char *path);
int         vault_create(Vault *v, const char *path, const char *master);
int         vault_open(Vault *v, const char *path, const char *master);
int         vault_save(Vault *v);
void        vault_close(Vault *v);
int         vault_find(const Vault *v, const char *name);
int         vault_set(Vault *v, const char *name, const char *pass);
void        vault_delete(Vault *v, int idx);
int         vault_change_master(Vault *v, const char *new_master);
void        clean_field(char *s);
void        secure_wipe(void *p, size_t n);
const char *vault_strerror(int err);

#endif
