#include "core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

static void read_secret(const char *prompt, char *out, size_t cap) {
    struct termios old, quiet;
    fprintf(stderr, "%s", prompt);
    fflush(stderr);
    int tty = isatty(STDIN_FILENO) && tcgetattr(STDIN_FILENO, &old) == 0;
    if (tty) { quiet = old; quiet.c_lflag &= ~(tcflag_t)ECHO; tcsetattr(STDIN_FILENO, TCSANOW, &quiet); }
    if (!fgets(out, (int)cap, stdin)) out[0] = 0;
    if (tty) { tcsetattr(STDIN_FILENO, TCSANOW, &old); fprintf(stderr, "\n"); }
    out[strcspn(out, "\r\n")] = 0;
}

static int copy_clip(const char *s) {
    const char *cmds[][2] = {{"wl-copy", "wl-copy"}, {"xclip", "xclip -selection clipboard"}, {"xsel", "xsel -b -i"}};
    for (int i = 0; i < 3; i++) {
        char probe[64];
        snprintf(probe, sizeof probe, "command -v %s >/dev/null 2>&1", cmds[i][0]);
        if (system(probe) == 0) {
            FILE *p = popen(cmds[i][1], "w");
            if (p) { fputs(s, p); pclose(p); return 1; }
        }
    }
    return 0;
}

static void usage(void) {
    printf(
        "Word Password Vault\n\n"
        "  wordpass gen [-w 2-5] [-d 2-4]     just print a password (no vault)\n"
        "  wordpass add NAME [-w N] [-d N]    generate + save a password for NAME\n"
        "  wordpass add NAME --own            save a password you type yourself\n"
        "  wordpass get NAME                  copy NAME's password to clipboard\n"
        "  wordpass show NAME                 print NAME's password\n"
        "  wordpass list                      list saved names\n"
        "  wordpass rm NAME                   delete NAME\n"
        "  wordpass passwd                    change master password\n\n"
        "Vault file: ~/.local/share/wordpass/vault.wpv (set WORDPASS_VAULT to override)\n");
}

static int unlock(Vault *v, const char *path) {
    char m1[256], m2[256];
    if (!vault_exists(path)) {
        printf("No vault yet - creating one at %s\n", path);
        printf("Choose a master password. It can NOT be recovered if you forget it.\n");
        read_secret("New master password: ", m1, sizeof m1);
        if (strlen(m1) < 10) { fprintf(stderr, "Use at least 10 characters.\n"); return 0; }
        read_secret("Repeat master password: ", m2, sizeof m2);
        if (strcmp(m1, m2) != 0) { fprintf(stderr, "They don't match.\n"); return 0; }
        int r = vault_create(v, path, m1);
        secure_wipe(m1, sizeof m1); secure_wipe(m2, sizeof m2);
        if (r) { fprintf(stderr, "%s\n", vault_strerror(r)); return 0; }
        return 1;
    }
    read_secret("Master password: ", m1, sizeof m1);
    int r = vault_open(v, path, m1);
    secure_wipe(m1, sizeof m1);
    if (r) { fprintf(stderr, "%s\n", vault_strerror(r)); return 0; }
    return 1;
}

int main(int argc, char **argv) {
    if (argc < 2) { usage(); return 0; }
    const char *cmd = argv[1];
    const char *name = (argc >= 3 && argv[2][0] != '-') ? argv[2] : NULL;
    GenOpts o = {3, 2, 0, 0};
    int own = 0;
    for (int i = 2; i < argc; i++) {
        if (!strcmp(argv[i], "-w") && i + 1 < argc) o.words = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-d") && i + 1 < argc) o.digits = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-m")) o.caps_mode = 1;
        else if (!strcmp(argv[i], "--own")) own = 1;
    }

    char pw[PASS_MAX_LEN + 1];
    if (!strcmp(cmd, "gen")) {
        double b = gen_password(&o, pw, sizeof pw);
        printf("%s\n(~%.0f bits - %s)\n", pw, b, gen_strength(b));
        return 0;
    }

    char path[1024];
    const char *env = getenv("WORDPASS_VAULT");
    if (env && *env) snprintf(path, sizeof path, "%s", env);
    else vault_default_path(path, sizeof path);

    int needs_name = !strcmp(cmd, "add") || !strcmp(cmd, "get") || !strcmp(cmd, "show") || !strcmp(cmd, "rm");
    int known = needs_name || !strcmp(cmd, "list") || !strcmp(cmd, "passwd");
    if (!known) { usage(); return 1; }
    if (needs_name && !name) { fprintf(stderr, "Give a name, e.g.: wordpass %s google\n", cmd); return 1; }

    Vault v;
    if (!unlock(&v, path)) return 1;
    int rc = 0;

    if (!strcmp(cmd, "list")) {
        if (v.count == 0) printf("(vault is empty)\n");
        for (int i = 0; i < v.count; i++) printf("  %s\n", v.items[i].name);
    } else if (!strcmp(cmd, "add")) {
        int existing = vault_find(&v, name);
        if (existing >= 0) {
            char ans[16];
            printf("'%s' already exists. Replace its password? The old one will be lost. [y/N] ", v.items[existing].name);
            if (!fgets(ans, sizeof ans, stdin) || (ans[0] != 'y' && ans[0] != 'Y')) { vault_close(&v); return 1; }
        }
        if (own) read_secret("Password to save: ", pw, sizeof pw);
        else gen_password(&o, pw, sizeof pw);
        if (!pw[0]) { fprintf(stderr, "Empty password - nothing saved.\n"); rc = 1; }
        else {
            vault_set(&v, name, pw);
            int r = vault_save(&v);
            if (r) { fprintf(stderr, "%s\n", vault_strerror(r)); rc = 1; }
            else {
                printf("Saved %s: %s\n", name, pw);
                if (copy_clip(pw)) printf("(copied to clipboard)\n");
            }
        }
    } else if (!strcmp(cmd, "get") || !strcmp(cmd, "show")) {
        int i = vault_find(&v, name);
        if (i < 0) { fprintf(stderr, "No entry called '%s'. Try: wordpass list\n", name); rc = 1; }
        else if (!strcmp(cmd, "show") || !copy_clip(v.items[i].pass)) printf("%s\n", v.items[i].pass);
        else printf("Copied password for %s to clipboard.\n", v.items[i].name);
    } else if (!strcmp(cmd, "rm")) {
        int i = vault_find(&v, name);
        if (i < 0) { fprintf(stderr, "No entry called '%s'.\n", name); rc = 1; }
        else {
            char ans[16];
            printf("Delete '%s' permanently? [y/N] ", v.items[i].name);
            if (fgets(ans, sizeof ans, stdin) && (ans[0] == 'y' || ans[0] == 'Y')) {
                vault_delete(&v, i);
                int r = vault_save(&v);
                printf("%s\n", r ? vault_strerror(r) : "Deleted.");
                rc = r ? 1 : 0;
            }
        }
    } else if (!strcmp(cmd, "passwd")) {
        char m1[256], m2[256];
        read_secret("New master password: ", m1, sizeof m1);
        read_secret("Repeat: ", m2, sizeof m2);
        if (strlen(m1) < 10 || strcmp(m1, m2)) { fprintf(stderr, "Too short (min 10) or doesn't match.\n"); rc = 1; }
        else { int r = vault_change_master(&v, m1); printf("%s\n", r ? vault_strerror(r) : "Master password changed."); rc = r ? 1 : 0; }
        secure_wipe(m1, sizeof m1); secure_wipe(m2, sizeof m2);
    }
    secure_wipe(pw, sizeof pw);
    vault_close(&v);
    return rc;
}
