#include "core.h"
#include "monocypher.h"
#include "words.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#ifdef _WIN32
#include <windows.h>
#include <bcrypt.h>
#include <shlobj.h>
#include <direct.h>
#else
#include <sys/random.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

#define NWORDS (sizeof(WORDS) / sizeof(WORDS[0]))
const char GEN_SEPS[] = "_-.!@#";
#define NSEPS 6

#define HDR_SIZE   28
#define FILE_MIN   (HDR_SIZE + 24 + 16)
#define KDF_BLOCKS (64 * 1024)
#define KDF_PASSES 3

void rand_bytes(void *buf, size_t n) {
#ifdef _WIN32
    if (BCryptGenRandom(NULL, buf, (ULONG)n, BCRYPT_USE_SYSTEM_PREFERRED_RNG) != 0) abort();
#else
    size_t got = 0;
    while (got < n) {
        ssize_t r = getrandom((char *)buf + got, n - got, 0);
        if (r > 0) got += (size_t)r;
    }
#endif
}

static uint32_t rand_below(uint32_t n) {
    uint32_t x, limit = UINT32_MAX - (UINT32_MAX % n);
    do { rand_bytes(&x, sizeof x); } while (x >= limit);
    return x % n;
}

void secure_wipe(void *p, size_t n) { crypto_wipe(p, n); }

double gen_password(const GenOpts *o, char *out, size_t cap) {
    double bits = 0;
    int words = o->words < 2 ? 2 : o->words > 5 ? 5 : o->words;
    int digits = o->digits < 2 ? 2 : o->digits > 4 ? 4 : o->digits;
    out[0] = 0;
    for (int i = 0; i < words; i++) {
        char w[32];
        snprintf(w, sizeof w, "%s", WORDS[rand_below(NWORDS)]);
        bits += log2((double)NWORDS);
        if (o->caps_mode == 0) {
            w[0] = (char)toupper((unsigned char)w[0]);
        } else {
            uint32_t c = rand_below(3);
            if (c == 0) w[0] = (char)toupper((unsigned char)w[0]);
            else if (c == 2) for (char *p = w; *p; p++) *p = (char)toupper((unsigned char)*p);
            bits += log2(3.0);
            if (i == 0 && c == 1) w[0] = (char)toupper((unsigned char)w[0]);
        }
        strncat(out, w, cap - strlen(out) - 1);
        if (i < words - 1) {
            char s[2] = {0, 0};
            if (o->sep_mode <= 0 || o->sep_mode > NSEPS) {
                s[0] = GEN_SEPS[rand_below(NSEPS)];
                bits += log2((double)NSEPS);
            } else s[0] = GEN_SEPS[o->sep_mode - 1];
            strncat(out, s, cap - strlen(out) - 1);
        }
    }
    for (int i = 0; i < digits; i++) {
        char d[2] = {(char)('0' + rand_below(10)), 0};
        strncat(out, d, cap - strlen(out) - 1);
    }
    bits += digits * log2(10.0);
    return bits;
}

const char *gen_strength(double bits) {
    if (bits < 45) return "Weak - add a word";
    if (bits < 60) return "Good for normal accounts";
    if (bits < 75) return "Strong";
    return "Very strong";
}

static void put32(uint8_t *p, uint32_t v) { p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24); }
static uint32_t get32(const uint8_t *p) { return p[0] | (p[1]<<8) | (p[2]<<16) | ((uint32_t)p[3]<<24); }

static int ci_cmp(const char *a, const char *b) {
    for (;; a++, b++) {
        int ca = tolower((unsigned char)*a), cb = tolower((unsigned char)*b);
        if (ca != cb || !ca) return ca - cb;
    }
}

void clean_field(char *s) {
    char *w = s;
    for (char *r = s; *r; r++) if (*r != '\t' && *r != '\n' && *r != '\r') *w++ = *r;
    *w = 0;
    while (w > s && isspace((unsigned char)w[-1])) *--w = 0;
    size_t lead = strspn(s, " ");
    if (lead) memmove(s, s + lead, strlen(s + lead) + 1);
}

const char *vault_strerror(int err) {
    switch (err) {
    case V_OK: return "OK";
    case V_ERR_IO: return "Could not read or write the vault file.";
    case V_ERR_PASSWORD: return "Wrong master password (or the vault file is damaged).";
    case V_ERR_FORMAT: return "This is not a valid vault file.";
    case V_ERR_MEM: return "Out of memory.";
    }
    return "Unknown error";
}

static int derive_key(Vault *v, const char *master) {
    void *work = malloc((size_t)v->nb_blocks * 1024);
    if (!work) return V_ERR_MEM;
    crypto_argon2_config cfg = {CRYPTO_ARGON2_ID, v->nb_blocks, v->nb_passes, 1};
    crypto_argon2_inputs in = {(const uint8_t *)master, v->salt, (uint32_t)strlen(master), 16};
    crypto_argon2(v->key, 32, work, cfg, in, crypto_argon2_no_extras);
    crypto_wipe(work, (size_t)v->nb_blocks * 1024);
    free(work);
    return V_OK;
}

#ifdef _WIN32
static void u2w(const char *s, wchar_t *w, int cap) { MultiByteToWideChar(CP_UTF8, 0, s, -1, w, cap); }
static FILE *xfopen(const char *path, const char *mode) {
    wchar_t wp[1024], wm[8];
    u2w(path, wp, 1024); u2w(mode, wm, 8);
    return _wfopen(wp, wm);
}
static int xmove(const char *a, const char *b, DWORD flags) {
    wchar_t wa[1024], wb[1024];
    u2w(a, wa, 1024); u2w(b, wb, 1024);
    return MoveFileExW(wa, wb, flags) != 0;
}
static int xremove(const char *p) { wchar_t w[1024]; u2w(p, w, 1024); return _wremove(w); }
#else
#define xfopen fopen
#define xremove remove
#endif
static void mkdir_p(const char *dir) {
#ifdef _WIN32
    wchar_t w[1024]; u2w(dir, w, 1024); _wmkdir(w);
#else
    char tmp[1024];
    snprintf(tmp, sizeof tmp, "%s", dir);
    for (char *p = tmp + 1; *p; p++)
        if (*p == '/') { *p = 0; mkdir(tmp, 0700); *p = '/'; }
    mkdir(tmp, 0700);
#endif
}

void vault_default_path(char *out, size_t cap) {
    char dir[1024];
#ifdef _WIN32
    wchar_t wad[MAX_PATH]; char appdata[1024] = ".";
    if (SHGetFolderPathW(NULL, CSIDL_APPDATA, NULL, 0, wad) == S_OK)
        WideCharToMultiByte(CP_UTF8, 0, wad, -1, appdata, sizeof appdata, NULL, NULL);
    snprintf(dir, sizeof dir, "%s\\WordPassVault", appdata);
    mkdir_p(dir);
    snprintf(out, cap, "%s\\vault.wpv", dir);
#else
    const char *x = getenv("XDG_DATA_HOME"), *h = getenv("HOME");
    if (x && *x) snprintf(dir, sizeof dir, "%s/wordpass", x);
    else snprintf(dir, sizeof dir, "%s/.local/share/wordpass", h ? h : ".");
    mkdir_p(dir);
    snprintf(out, cap, "%s/vault.wpv", dir);
#endif
}

int vault_exists(const char *path) {
    FILE *f = xfopen(path, "rb");
    if (!f) return 0;
    fclose(f);
    return 1;
}

static int grow(Vault *v) {
    if (v->count < v->cap) return 1;
    int ncap = v->cap ? v->cap * 2 : 32;
    Entry *n = calloc((size_t)ncap, sizeof(Entry));
    if (!n) return 0;
    if (v->items) {
        memcpy(n, v->items, (size_t)v->count * sizeof(Entry));
        crypto_wipe(v->items, (size_t)v->cap * sizeof(Entry));
        free(v->items);
    }
    v->items = n;
    v->cap = ncap;
    return 1;
}

int vault_find(const Vault *v, const char *name) {
    for (int i = 0; i < v->count; i++)
        if (ci_cmp(v->items[i].name, name) == 0) return i;
    return -1;
}

int vault_set(Vault *v, const char *name, const char *pass) {
    int i = vault_find(v, name);
    if (i < 0) {
        if (!grow(v)) return V_ERR_MEM;

        i = 0;
        while (i < v->count && ci_cmp(v->items[i].name, name) < 0) i++;
        memmove(&v->items[i + 1], &v->items[i], (size_t)(v->count - i) * sizeof(Entry));
        v->count++;
        memset(&v->items[i], 0, sizeof(Entry));
        snprintf(v->items[i].name, sizeof v->items[i].name, "%s", name);
        clean_field(v->items[i].name);
    }
    crypto_wipe(v->items[i].pass, sizeof v->items[i].pass);
    snprintf(v->items[i].pass, sizeof v->items[i].pass, "%s", pass);
    clean_field(v->items[i].pass);
    return i;
}

void vault_delete(Vault *v, int idx) {
    if (idx < 0 || idx >= v->count) return;
    crypto_wipe(&v->items[idx], sizeof(Entry));
    memmove(&v->items[idx], &v->items[idx + 1], (size_t)(v->count - idx - 1) * sizeof(Entry));
    v->count--;
    crypto_wipe(&v->items[v->count], sizeof(Entry));
}

static int write_file(const char *path, const uint8_t *data, size_t n) {
    char tmp[1100], bak[1100];
    snprintf(tmp, sizeof tmp, "%s.tmp", path);
    snprintf(bak, sizeof bak, "%s.bak", path);
    FILE *f = xfopen(tmp, "wb");
    if (!f) return V_ERR_IO;
    size_t w = fwrite(data, 1, n, f);
    int ok = (w == n) && fflush(f) == 0;
#ifndef _WIN32
    if (ok) fsync(fileno(f));
#endif
    if (fclose(f) != 0) ok = 0;
    if (!ok) { xremove(tmp); return V_ERR_IO; }
#ifdef _WIN32
    if (vault_exists(path)) xmove(path, bak, MOVEFILE_REPLACE_EXISTING);
    if (!xmove(tmp, path, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) return V_ERR_IO;
#else
    if (vault_exists(path)) { remove(bak); if (link(path, bak) != 0) {  } }
    if (rename(tmp, path) != 0) return V_ERR_IO;
    chmod(path, 0600);
#endif
    return V_OK;
}

int vault_save(Vault *v) {
    if (!v->open) return V_ERR_IO;
    size_t plen = 0;
    for (int i = 0; i < v->count; i++) plen += strlen(v->items[i].name) + strlen(v->items[i].pass) + 2;
    size_t total = FILE_MIN + plen;
    uint8_t *buf = malloc(total + 1);
    uint8_t *plain = malloc(plen + 1);
    if (!buf || !plain) { free(buf); free(plain); return V_ERR_MEM; }

    size_t p = 0;
    for (int i = 0; i < v->count; i++)
        p += (size_t)sprintf((char *)plain + p, "%s\t%s\n", v->items[i].name, v->items[i].pass);

    memcpy(buf, "WPV1", 4);
    put32(buf + 4, v->nb_blocks);
    put32(buf + 8, v->nb_passes);
    memcpy(buf + 12, v->salt, 16);
    uint8_t *nonce = buf + HDR_SIZE, *mac = nonce + 24, *ct = mac + 16;
    rand_bytes(nonce, 24);
    crypto_aead_lock(ct, mac, v->key, nonce, buf, HDR_SIZE, plain, plen);
    crypto_wipe(plain, plen + 1);
    free(plain);

    int r = write_file(v->path, buf, total);
    free(buf);
    return r;
}

int vault_create(Vault *v, const char *path, const char *master) {
    memset(v, 0, sizeof *v);
    snprintf(v->path, sizeof v->path, "%s", path);
    v->nb_blocks = KDF_BLOCKS;
    v->nb_passes = KDF_PASSES;
    rand_bytes(v->salt, 16);
    int r = derive_key(v, master);
    if (r) return r;
    v->open = 1;
    r = vault_save(v);
    if (r) vault_close(v);
    return r;
}

int vault_open(Vault *v, const char *path, const char *master) {
    memset(v, 0, sizeof *v);
    snprintf(v->path, sizeof v->path, "%s", path);
    FILE *f = xfopen(path, "rb");
    if (!f) return V_ERR_IO;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz < FILE_MIN || sz > 64L * 1024 * 1024) { fclose(f); return V_ERR_FORMAT; }
    uint8_t *buf = malloc((size_t)sz);
    if (!buf) { fclose(f); return V_ERR_MEM; }
    if (fread(buf, 1, (size_t)sz, f) != (size_t)sz) { fclose(f); free(buf); return V_ERR_IO; }
    fclose(f);

    if (memcmp(buf, "WPV1", 4) != 0) { free(buf); return V_ERR_FORMAT; }
    v->nb_blocks = get32(buf + 4);
    v->nb_passes = get32(buf + 8);
    if (v->nb_blocks < 8 || v->nb_blocks > 1024 * 1024 || v->nb_passes < 1 || v->nb_passes > 20) {
        free(buf); return V_ERR_FORMAT;
    }
    memcpy(v->salt, buf + 12, 16);
    int r = derive_key(v, master);
    if (r) { free(buf); return r; }

    size_t clen = (size_t)sz - FILE_MIN;
    uint8_t *plain = malloc(clen + 1);
    if (!plain) { free(buf); return V_ERR_MEM; }
    const uint8_t *nonce = buf + HDR_SIZE, *mac = nonce + 24, *ct = mac + 16;
    if (crypto_aead_unlock(plain, mac, v->key, nonce, buf, HDR_SIZE, ct, clen) != 0) {
        crypto_wipe(v->key, 32);
        free(plain); free(buf);
        return V_ERR_PASSWORD;
    }
    free(buf);
    plain[clen] = 0;
    v->open = 1;

    char *line = (char *)plain;
    while (line && *line) {
        char *nl = strchr(line, '\n');
        if (nl) *nl = 0;
        char *tab = strchr(line, '\t');
        if (tab) {
            *tab = 0;
            if (vault_set(v, line, tab + 1) < 0) { crypto_wipe(plain, clen); free(plain); vault_close(v); return V_ERR_MEM; }
        }
        line = nl ? nl + 1 : NULL;
    }
    crypto_wipe(plain, clen + 1);
    free(plain);
    return V_OK;
}

int vault_change_master(Vault *v, const char *new_master) {
    uint8_t old_key[32], old_salt[16];
    memcpy(old_key, v->key, 32);
    memcpy(old_salt, v->salt, 16);
    rand_bytes(v->salt, 16);
    int r = derive_key(v, new_master);
    if (r == V_OK) r = vault_save(v);
    if (r != V_OK) { memcpy(v->key, old_key, 32); memcpy(v->salt, old_salt, 16); }
    crypto_wipe(old_key, 32);
    return r;
}

void vault_close(Vault *v) {
    if (v->items) {
        crypto_wipe(v->items, (size_t)v->cap * sizeof(Entry));
        free(v->items);
    }
    crypto_wipe(v, sizeof *v);
}
