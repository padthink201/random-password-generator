#define UNICODE
#define _UNICODE
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <string.h>
#include "core.h"

enum {
    ID_L_MSG = 100, ID_L_PW1, ID_L_PW2, ID_L_BTN, ID_L_ERR, ID_L_TITLE, ID_L_LBL2,
    ID_NAME = 200, ID_PASS, ID_SAVE, ID_WORDS, ID_DIGITS, ID_SEP, ID_CAPS, ID_SEARCH,
    ID_SHOW, ID_LIST, ID_COPY, ID_DEL, ID_MASTER, ID_LOCK, ID_STATUS, ID_GENONLY, ID_COPYNAME, ID_INFO
};
#define TIMER_CLIP 1
#define TIMER_IDLE 2
#define CLIP_SECONDS 30
#define IDLE_LOCK_MS (5 * 60 * 1000)

static HWND hMain;
static HFONT fUi, fTitle, fMono, fBig;
static int settingPass;
static HWND lockCtl[8]; static int nLock;
static HWND vaultCtl[40]; static int nVault;
static HWND hLMsg, hLPw1, hLPw2, hLLbl2, hLErr, hLBtn;
static HWND hInfo, hName, hPass, hWords, hDigits, hSep, hCaps, hSearch, hShow, hList, hStatus;
static Vault V;
static int creating;
static char vaultPath[1024];
static wchar_t clipCopy[PASS_MAX_LEN + 1];

static void get_utf8(HWND h, char *out, int cap) {
    wchar_t w[512];
    GetWindowTextW(h, w, 512);
    WideCharToMultiByte(CP_UTF8, 0, w, -1, out, cap, NULL, NULL);
    SecureZeroMemory(w, sizeof w);
}
static void to_wide(const char *s, wchar_t *w, int cap) {
    MultiByteToWideChar(CP_UTF8, 0, s, -1, w, cap);
}
static void set_utf8(HWND h, const char *s) {
    wchar_t w[512];
    to_wide(s, w, 512);
    SetWindowTextW(h, w);
    SecureZeroMemory(w, sizeof w);
}
static void status(const wchar_t *fmt, ...) {
    wchar_t buf[400];
    va_list ap; va_start(ap, fmt);
    _vsnwprintf(buf, 399, fmt, ap); buf[399] = 0;
    va_end(ap);
    SetWindowTextW(hStatus, buf);
}

static HWND mk(const wchar_t *cls, const wchar_t *txt, DWORD style, DWORD ex,
               int x, int y, int w, int h, int id, HFONT f) {
    HWND c = CreateWindowExW(ex, cls, txt, WS_CHILD | style, x, y, w, h, hMain,
                             (HMENU)(INT_PTR)id, GetModuleHandleW(NULL), NULL);
    SendMessageW(c, WM_SETFONT, (WPARAM)(f ? f : fUi), TRUE);
    return c;
}
#define L(c) (lockCtl[nLock++] = (c))
#define VC(c) (vaultCtl[nVault++] = (c))

static HWND combo(int x, int y, int w, int id, const wchar_t **items, int n, int sel) {
    HWND c = mk(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, 0, x, y, w, 240, id, NULL);
    for (int i = 0; i < n; i++) SendMessageW(c, CB_ADDSTRING, 0, (LPARAM)items[i]);
    SendMessageW(c, CB_SETCURSEL, sel, 0);
    return c;
}

static void copy_secret(const char *utf8) {
    to_wide(utf8, clipCopy, PASS_MAX_LEN + 1);
    size_t bytes = (wcslen(clipCopy) + 1) * sizeof(wchar_t);
    if (!OpenClipboard(hMain)) return;
    EmptyClipboard();
    HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (h) { memcpy(GlobalLock(h), clipCopy, bytes); GlobalUnlock(h); SetClipboardData(CF_UNICODETEXT, h); }
    UINT fHist = RegisterClipboardFormatW(L"CanIncludeInClipboardHistory");
    UINT fCloud = RegisterClipboardFormatW(L"CanUploadToCloudClipboard");
    UINT fMon = RegisterClipboardFormatW(L"ExcludeClipboardContentFromMonitorProcessing");
    DWORD zero = 0;
    HGLOBAL z1 = GlobalAlloc(GMEM_MOVEABLE, 4), z2 = GlobalAlloc(GMEM_MOVEABLE, 4), z3 = GlobalAlloc(GMEM_MOVEABLE, 4);
    if (z1) { memcpy(GlobalLock(z1), &zero, 4); GlobalUnlock(z1); SetClipboardData(fHist, z1); }
    if (z2) { memcpy(GlobalLock(z2), &zero, 4); GlobalUnlock(z2); SetClipboardData(fCloud, z2); }
    if (z3) { memcpy(GlobalLock(z3), &zero, 4); GlobalUnlock(z3); SetClipboardData(fMon, z3); }
    CloseClipboard();
    SetTimer(hMain, TIMER_CLIP, CLIP_SECONDS * 1000, NULL);
}

static void clear_clip_if_ours(void) {
    KillTimer(hMain, TIMER_CLIP);
    if (!clipCopy[0] || !OpenClipboard(hMain)) return;
    HANDLE h = GetClipboardData(CF_UNICODETEXT);
    if (h) {
        const wchar_t *t = GlobalLock(h);
        if (t && wcscmp(t, clipCopy) == 0) EmptyClipboard();
        GlobalUnlock(h);
    }
    CloseClipboard();
    SecureZeroMemory(clipCopy, sizeof clipCopy);
}

static int selected_index(void) {
    int row = (int)SendMessageW(hList, LVM_GETNEXTITEM, (WPARAM)-1, LVNI_SELECTED);
    if (row < 0) return -1;
    LVITEMW it = {0};
    it.mask = LVIF_PARAM; it.iItem = row;
    SendMessageW(hList, LVM_GETITEMW, 0, (LPARAM)&it);
    return (int)it.lParam;
}

static int contains_ci(const char *hay, const char *needle) {
    if (!*needle) return 1;
    size_t n = strlen(needle);
    for (; *hay; hay++) if (_strnicmp(hay, needle, n) == 0) return 1;
    return 0;
}

static void refresh_list(int select_idx) {
    char filter[256];
    get_utf8(hSearch, filter, sizeof filter);
    int show = SendMessageW(hShow, BM_GETCHECK, 0, 0) == BST_CHECKED;
    SendMessageW(hList, WM_SETREDRAW, FALSE, 0);
    SendMessageW(hList, LVM_DELETEALLITEMS, 0, 0);
    int row = 0, selRow = -1;
    for (int i = 0; i < V.count; i++) {
        if (!contains_ci(V.items[i].name, filter)) continue;
        wchar_t w[512];
        to_wide(V.items[i].name, w, 512);
        LVITEMW it = {0};
        it.mask = LVIF_TEXT | LVIF_PARAM; it.iItem = row; it.pszText = w; it.lParam = i;
        SendMessageW(hList, LVM_INSERTITEMW, 0, (LPARAM)&it);
        if (show) to_wide(V.items[i].pass, w, 512);
        else wcscpy(w, L"\x2022\x2022\x2022\x2022\x2022\x2022\x2022\x2022\x2022\x2022");
        LVITEMW sub = {0};
        sub.iSubItem = 1; sub.pszText = w;
        SendMessageW(hList, LVM_SETITEMTEXTW, row, (LPARAM)&sub);
        SecureZeroMemory(w, sizeof w);
        if (i == select_idx) selRow = row;
        row++;
    }
    if (selRow >= 0) {
        LVITEMW st = {0};
        st.stateMask = LVIS_SELECTED | LVIS_FOCUSED; st.state = st.stateMask;
        SendMessageW(hList, LVM_SETITEMSTATE, selRow, (LPARAM)&st);
        SendMessageW(hList, LVM_ENSUREVISIBLE, selRow, FALSE);
    }
    SendMessageW(hList, WM_SETREDRAW, TRUE, 0);
    InvalidateRect(hList, NULL, TRUE);
}

static void show_page(int vault) {
    for (int i = 0; i < nLock; i++) ShowWindow(lockCtl[i], vault ? SW_HIDE : SW_SHOW);
    for (int i = 0; i < nVault; i++) ShowWindow(vaultCtl[i], vault ? SW_SHOW : SW_HIDE);
    if (!vault) {
        ShowWindow(hLPw2, creating ? SW_SHOW : SW_HIDE);
        ShowWindow(hLLbl2, creating ? SW_SHOW : SW_HIDE);
        SetWindowTextW(hLMsg, creating
            ? L"Create a master password for your new vault (at least 10 characters).\n"
              L"Write it down somewhere safe - if you forget it, your saved passwords can NOT be recovered."
            : L"Enter your master password to unlock the vault.");
        SetWindowTextW(hLBtn, creating ? L"Create vault" : L"Unlock");
        SetFocus(hLPw1);
    } else {
        SetFocus(hName);
    }
}

static void lock_vault(void) {
    clear_clip_if_ours();
    vault_close(&V);
    SendMessageW(hList, LVM_DELETEALLITEMS, 0, 0);
    settingPass = 1; SetWindowTextW(hPass, L""); settingPass = 0;
    SetWindowTextW(hInfo, L"");
    SetWindowTextW(hSearch, L"");
    SendMessageW(hShow, BM_SETCHECK, BST_UNCHECKED, 0);
    creating = !vault_exists(vaultPath);
    SetWindowTextW(hLErr, L"");
    show_page(0);
}

static void do_generate_into_field(void);
static void do_unlock(void) {
    char m1[256], m2[256];
    get_utf8(hLPw1, m1, sizeof m1);
    get_utf8(hLPw2, m2, sizeof m2);
    SetWindowTextW(hLPw1, L""); SetWindowTextW(hLPw2, L"");
    int r;
    if (creating) {
        if (strlen(m1) < 10) { SetWindowTextW(hLErr, L"Too short - use at least 10 characters."); goto out; }
        if (strcmp(m1, m2) != 0) { SetWindowTextW(hLErr, L"The two passwords don't match."); goto out; }
    }
    SetWindowTextW(hLErr, L"Working...");
    UpdateWindow(hMain);
    HCURSOR old = SetCursor(LoadCursor(NULL, IDC_WAIT));
    r = creating ? vault_create(&V, vaultPath, m1) : vault_open(&V, vaultPath, m1);
    SetCursor(old);
    if (r != V_OK) {
        wchar_t w[200]; to_wide(vault_strerror(r), w, 200);
        SetWindowTextW(hLErr, w);
        goto out;
    }
    SetWindowTextW(hLErr, L"");
    show_page(1);
    refresh_list(-1);
    do_generate_into_field();
    status(creating ? L"Vault created. Type an account name and press Enter to save the password above." :
                      L"Unlocked - %d saved passwords.", V.count);
    creating = 0;
    SecureZeroMemory(m1, sizeof m1); SecureZeroMemory(m2, sizeof m2);
    SetFocus(hName);
    return;
out:
    SecureZeroMemory(m1, sizeof m1); SecureZeroMemory(m2, sizeof m2);
    SetFocus(hLPw1);
}

static void read_gen_opts(GenOpts *o) {
    o->words = (int)SendMessageW(hWords, CB_GETCURSEL, 0, 0) + 2;
    o->digits = (int)SendMessageW(hDigits, CB_GETCURSEL, 0, 0) + 2;
    o->sep_mode = (int)SendMessageW(hSep, CB_GETCURSEL, 0, 0);
    o->caps_mode = (int)SendMessageW(hCaps, CB_GETCURSEL, 0, 0);
}

static void do_generate_into_field(void) {
    GenOpts o; char pw[PASS_MAX_LEN + 1];
    read_gen_opts(&o);
    double b = gen_password(&o, pw, sizeof pw);
    settingPass = 1;
    set_utf8(hPass, pw);
    settingPass = 0;
    wchar_t s[160]; wchar_t ws[80]; to_wide(gen_strength(b), ws, 80);
    _snwprintf(s, 159, L"%d characters  \x2022  ~%.0f bits  \x2022  %ls", (int)strlen(pw), b, ws); s[159] = 0;
    SetWindowTextW(hInfo, s);
    SecureZeroMemory(pw, sizeof pw);
}

static void do_save(void) {
    char name[NAME_MAX_LEN + 1], pw[PASS_MAX_LEN + 1];
    get_utf8(hName, name, sizeof name);
    get_utf8(hPass, pw, sizeof pw);
    clean_field(name); clean_field(pw);
    if (!name[0]) { status(L"Type a name first, e.g. google or instagram."); SetFocus(hName); return; }

    int existing = vault_find(&V, name);
    if (existing >= 0) {
        wchar_t w[300], wn[200];
        to_wide(V.items[existing].name, wn, 200);
        _snwprintf(w, 299, L"\"%ls\" is already saved.\n\nReplace its password? The old password will be "
                           L"deleted, so only do this after you've changed it on the website too.", wn);
        w[299] = 0;
        if (MessageBoxW(hMain, w, L"Replace password?", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) return;
    }
    double bits = 0;
    int generated = 0;
    if (!pw[0]) {
        GenOpts o; read_gen_opts(&o);
        bits = gen_password(&o, pw, sizeof pw);
        generated = 1;
    }
    int idx = vault_set(&V, name, pw);
    int r = idx < 0 ? idx : vault_save(&V);
    if (r != V_OK) {
        wchar_t w[200]; to_wide(vault_strerror(r), w, 200);
        MessageBoxW(hMain, w, L"Not saved", MB_ICONERROR);
    } else {
        copy_secret(pw);
        refresh_list(idx);
        wchar_t wn[200]; to_wide(V.items[idx].name, wn, 200);
        if (generated)
            status(L"Saved \"%ls\" (%.0f bits). Password copied - clipboard clears in %d s.", wn, bits, CLIP_SECONDS);
        else
            status(L"Saved \"%ls\". Password copied - clipboard clears in %d s.", wn, CLIP_SECONDS);
        SetWindowTextW(hName, L"");
        do_generate_into_field();
        SetFocus(hName);
    }
    SecureZeroMemory(pw, sizeof pw);
}

static void do_copy(int name_only) {
    int i = selected_index();
    if (i < 0) { status(L"Select an account in the list first."); return; }
    wchar_t wn[200]; to_wide(V.items[i].name, wn, 200);
    if (name_only) {
        size_t bytes = (wcslen(wn) + 1) * sizeof(wchar_t);
        if (OpenClipboard(hMain)) {
            EmptyClipboard();
            HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, bytes);
            if (h) { memcpy(GlobalLock(h), wn, bytes); GlobalUnlock(h); SetClipboardData(CF_UNICODETEXT, h); }
            CloseClipboard();
        }
        status(L"Copied the name \"%ls\".", wn);
        return;
    }
    copy_secret(V.items[i].pass);
    status(L"Copied password for \"%ls\" - clipboard clears in %d s.", wn, CLIP_SECONDS);
}

static void do_delete(void) {
    int i = selected_index();
    if (i < 0) { status(L"Select an account in the list first."); return; }
    wchar_t w[300], wn[200];
    to_wide(V.items[i].name, wn, 200);
    _snwprintf(w, 299, L"Delete \"%ls\" and its password permanently?", wn); w[299] = 0;
    if (MessageBoxW(hMain, w, L"Delete", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) return;
    vault_delete(&V, i);
    int r = vault_save(&V);
    refresh_list(-1);
    if (r) { wchar_t e[200]; to_wide(vault_strerror(r), e, 200); MessageBoxW(hMain, e, L"Error", MB_ICONERROR); }
    else status(L"Deleted \"%ls\".", wn);
}

static HWND dP1, dP2, dErr; static int dResult;
static LRESULT CALLBACK DlgProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    if (m == WM_COMMAND && (LOWORD(wp) == IDOK || LOWORD(wp) == IDCANCEL)) {
        if (LOWORD(wp) == IDCANCEL) { dResult = 0; DestroyWindow(h); return 0; }
        char a[256], b[256];
        get_utf8(dP1, a, sizeof a); get_utf8(dP2, b, sizeof b);
        if (strlen(a) < 10) SetWindowTextW(dErr, L"At least 10 characters.");
        else if (strcmp(a, b)) SetWindowTextW(dErr, L"They don't match.");
        else {
            SetWindowTextW(dErr, L"Working...");
            UpdateWindow(h);
            int r = vault_change_master(&V, a);
            if (r) { wchar_t w[200]; to_wide(vault_strerror(r), w, 200); SetWindowTextW(dErr, w); }
            else { dResult = 1; DestroyWindow(h); }
        }
        SecureZeroMemory(a, sizeof a); SecureZeroMemory(b, sizeof b);
        return 0;
    }
    if (m == WM_CLOSE) { dResult = 0; DestroyWindow(h); return 0; }
    return DefWindowProcW(h, m, wp, lp);
}

static void do_change_master(void) {
    static int reg;
    HINSTANCE hi = GetModuleHandleW(NULL);
    if (!reg) {
        WNDCLASSW wc = {0};
        wc.lpfnWndProc = DlgProc; wc.hInstance = hi; wc.hCursor = LoadCursor(NULL, IDC_ARROW);
        wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1); wc.lpszClassName = L"WPVDlg";
        RegisterClassW(&wc); reg = 1;
    }
    RECT pr; GetWindowRect(hMain, &pr);
    RECT r = {0, 0, 380, 200};
    DWORD st = WS_POPUP | WS_CAPTION | WS_SYSMENU;
    AdjustWindowRect(&r, st, FALSE);
    int w = r.right - r.left, hgt = r.bottom - r.top;
    HWND d = CreateWindowExW(WS_EX_DLGMODALFRAME, L"WPVDlg", L"Change master password", st,
                             pr.left + 140, pr.top + 140, w, hgt, hMain, NULL, hi, NULL);
    #define DC(cls, txt, style, x, y, cw, ch, id) do { HWND _c = CreateWindowExW( \
        (style) & ES_PASSWORD ? WS_EX_CLIENTEDGE : 0, cls, txt, WS_CHILD | WS_VISIBLE | (style), \
        x, y, cw, ch, d, (HMENU)(INT_PTR)(id), hi, NULL); SendMessageW(_c, WM_SETFONT, (WPARAM)fUi, TRUE); \
        if ((id) == 901) dP1 = _c; if ((id) == 902) dP2 = _c; if ((id) == 903) dErr = _c; } while (0)
    DC(L"STATIC", L"New master password:", 0, 16, 18, 150, 20, 0);
    DC(L"EDIT", L"", ES_PASSWORD | WS_TABSTOP | ES_AUTOHSCROLL, 170, 14, 194, 26, 901);
    DC(L"STATIC", L"Repeat it:", 0, 16, 56, 150, 20, 0);
    DC(L"EDIT", L"", ES_PASSWORD | WS_TABSTOP | ES_AUTOHSCROLL, 170, 52, 194, 26, 902);
    DC(L"STATIC", L"", 0, 16, 94, 348, 40, 903);
    DC(L"BUTTON", L"Change", BS_DEFPUSHBUTTON | WS_TABSTOP, 170, 150, 94, 32, IDOK);
    DC(L"BUTTON", L"Cancel", WS_TABSTOP, 270, 150, 94, 32, IDCANCEL);
    #undef DC
    EnableWindow(hMain, FALSE);
    ShowWindow(d, SW_SHOW);
    SetFocus(dP1);
    dResult = -1;
    MSG msg;
    while (dResult == -1 && GetMessageW(&msg, NULL, 0, 0)) {
        if (msg.message == WM_KEYDOWN && msg.wParam == VK_RETURN && GetParent(msg.hwnd) == d) {
            SendMessageW(d, WM_COMMAND, IDOK, 0); continue;
        }
        if (msg.message == WM_KEYDOWN && msg.wParam == VK_ESCAPE && GetParent(msg.hwnd) == d) {
            SendMessageW(d, WM_COMMAND, IDCANCEL, 0); continue;
        }
        if (!IsDialogMessageW(d, &msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    EnableWindow(hMain, TRUE);
    SetForegroundWindow(hMain);
    if (dResult == 1) status(L"Master password changed.");
}

static void build(void) {

    L(mk(L"STATIC", L"Word Password Generator + Vault", SS_CENTER, 0, 20, 70, 620, 40, ID_L_TITLE, fTitle));
    hLMsg = L(mk(L"STATIC", L"", SS_CENTER, 0, 60, 130, 540, 60, ID_L_MSG, NULL));
    L(mk(L"STATIC", L"Master password:", 0, 0, 110, 206, 150, 22, 0, NULL));
    hLPw1 = L(mk(L"EDIT", L"", ES_PASSWORD | ES_AUTOHSCROLL | WS_TABSTOP, WS_EX_CLIENTEDGE, 260, 202, 270, 28, ID_L_PW1, NULL));
    hLLbl2 = L(mk(L"STATIC", L"Repeat it:", 0, 0, 110, 246, 150, 22, ID_L_LBL2, NULL));
    hLPw2 = L(mk(L"EDIT", L"", ES_PASSWORD | ES_AUTOHSCROLL | WS_TABSTOP, WS_EX_CLIENTEDGE, 260, 242, 270, 28, ID_L_PW2, NULL));
    hLBtn = L(mk(L"BUTTON", L"Unlock", BS_DEFPUSHBUTTON | WS_TABSTOP, 0, 260, 286, 140, 36, ID_L_BTN, NULL));
    hLErr = L(mk(L"STATIC", L"", SS_CENTER, 0, 60, 334, 540, 40, ID_L_ERR, NULL));

    hPass = VC(mk(L"EDIT", L"", ES_AUTOHSCROLL | ES_CENTER | WS_TABSTOP, WS_EX_CLIENTEDGE, 16, 14, 528, 46, ID_PASS, fBig));
    VC(mk(L"BUTTON", L"New", WS_TABSTOP, 0, 552, 14, 92, 46, ID_GENONLY, NULL));
    hInfo = VC(mk(L"STATIC", L"", SS_CENTER, 0, 16, 66, 528, 20, ID_INFO, NULL));

    static const wchar_t *wds[] = {L"2 words", L"3 words", L"4 words", L"5 words"};
    static const wchar_t *dgs[] = {L"2 digits", L"3 digits", L"4 digits"};
    static const wchar_t *sps[] = {L"Random symbols", L"Always _", L"Always -", L"Always .",
                                   L"Always !", L"Always @", L"Always #"};
    static const wchar_t *cps[] = {L"Capitalise Each", L"Mixed case"};
    hWords = VC(combo(16, 94, 110, ID_WORDS, wds, 4, 1));
    hDigits = VC(combo(134, 94, 110, ID_DIGITS, dgs, 3, 0));
    hSep = VC(combo(252, 94, 160, ID_SEP, sps, 7, 0));
    hCaps = VC(combo(420, 94, 150, ID_CAPS, cps, 2, 0));

    VC(mk(L"STATIC", L"Save as:", 0, 0, 16, 144, 70, 22, 0, NULL));
    hName = VC(mk(L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, WS_EX_CLIENTEDGE, 86, 140, 398, 30, ID_NAME, NULL));
    SendMessageW(hName, EM_SETCUEBANNER, TRUE, (LPARAM)L"account name, e.g. google  -  then press Enter");
    VC(mk(L"BUTTON", L"Save to vault", BS_DEFPUSHBUTTON | WS_TABSTOP, 0, 492, 139, 152, 32, ID_SAVE, NULL));

    VC(mk(L"STATIC", L"Search:", 0, 0, 16, 194, 60, 22, 0, NULL));
    hSearch = VC(mk(L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, WS_EX_CLIENTEDGE, 86, 190, 254, 28, ID_SEARCH, NULL));
    hShow = VC(mk(L"BUTTON", L"Show passwords", BS_AUTOCHECKBOX | WS_TABSTOP, 0, 352, 194, 160, 22, ID_SHOW, NULL));

    hList = VC(mk(WC_LISTVIEWW, L"", LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS | WS_TABSTOP,
                  WS_EX_CLIENTEDGE, 16, 228, 628, 236, ID_LIST, NULL));
    SendMessageW(hList, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_DOUBLEBUFFER);
    LVCOLUMNW col = {0};
    col.mask = LVCF_TEXT | LVCF_WIDTH;
    col.cx = 230; col.pszText = L"Account";
    SendMessageW(hList, LVM_INSERTCOLUMNW, 0, (LPARAM)&col);
    col.cx = 374; col.pszText = L"Password";
    SendMessageW(hList, LVM_INSERTCOLUMNW, 1, (LPARAM)&col);

    VC(mk(L"BUTTON", L"Copy password", WS_TABSTOP, 0, 16, 474, 130, 32, ID_COPY, NULL));
    VC(mk(L"BUTTON", L"Copy name", WS_TABSTOP, 0, 152, 474, 100, 32, ID_COPYNAME, NULL));
    VC(mk(L"BUTTON", L"Delete", WS_TABSTOP, 0, 258, 474, 90, 32, ID_DEL, NULL));
    VC(mk(L"BUTTON", L"Change master password", WS_TABSTOP, 0, 354, 474, 190, 32, ID_MASTER, NULL));
    VC(mk(L"BUTTON", L"Lock", WS_TABSTOP, 0, 554, 474, 90, 32, ID_LOCK, NULL));
    hStatus = VC(mk(L"STATIC", L"", SS_LEFTNOWORDWRAP, 0, 16, 514, 628, 22, ID_STATUS, NULL));
}

static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case ID_L_BTN: do_unlock(); return 0;
        case ID_SAVE: do_save(); return 0;
        case ID_GENONLY: do_generate_into_field(); return 0;
        case ID_COPY: do_copy(0); return 0;
        case ID_COPYNAME: do_copy(1); return 0;
        case ID_DEL: do_delete(); return 0;
        case ID_MASTER: do_change_master(); return 0;
        case ID_LOCK: lock_vault(); return 0;
        case ID_SHOW: refresh_list(selected_index()); return 0;
        case ID_SEARCH: if (HIWORD(wp) == EN_CHANGE && V.open) refresh_list(-1); return 0;
        case ID_WORDS: case ID_DIGITS: case ID_SEP: case ID_CAPS:
            if (HIWORD(wp) == CBN_SELCHANGE) do_generate_into_field();
            return 0;
        case ID_PASS:
            if (HIWORD(wp) == EN_CHANGE && !settingPass) {
                int n = GetWindowTextLengthW(hPass);
                if (n) { wchar_t s[120]; _snwprintf(s, 119, L"Your own password  \x2022  %d characters", n); s[119] = 0; SetWindowTextW(hInfo, s); }
                else SetWindowTextW(hInfo, L"Empty - a new password will be generated when you save");
            }
            return 0;
        }
        break;
    case WM_NOTIFY: {
        NMHDR *n = (NMHDR *)lp;
        if (n->idFrom == ID_LIST && n->code == NM_DBLCLK) do_copy(0);
        break;
    }
    case WM_TIMER:
        if (wp == TIMER_CLIP) { clear_clip_if_ours(); if (V.open) status(L"Clipboard cleared."); }
        if (wp == TIMER_IDLE && V.open) {
            LASTINPUTINFO li = {sizeof li, 0};
            if (GetLastInputInfo(&li) && GetTickCount() - li.dwTime > IDLE_LOCK_MS) lock_vault();
        }
        return 0;
    case WM_CTLCOLORSTATIC:
        if ((HWND)lp == hLErr) { SetTextColor((HDC)wp, RGB(190, 30, 30)); SetBkMode((HDC)wp, TRANSPARENT);
                                 return (LRESULT)GetSysColorBrush(COLOR_BTNFACE); }
        break;
    case WM_CLOSE:
        clear_clip_if_ours();
        vault_close(&V);
        DestroyWindow(h);
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE hi, HINSTANCE hp, LPSTR cmd, int show) {
    (void)hp; (void)cmd;
    SetProcessDPIAware();
    INITCOMMONCONTROLSEX icc = {sizeof icc, ICC_STANDARD_CLASSES | ICC_LISTVIEW_CLASSES};
    InitCommonControlsEx(&icc);

    wchar_t exe[MAX_PATH]; char exeU[1024];
    GetModuleFileNameW(NULL, exe, MAX_PATH);
    wchar_t *slash = wcsrchr(exe, L'\\'); if (slash) slash[1] = 0;
    wcscat(exe, L"vault.wpv");
    WideCharToMultiByte(CP_UTF8, 0, exe, -1, exeU, sizeof exeU, NULL, NULL);
    if (vault_exists(exeU)) snprintf(vaultPath, sizeof vaultPath, "%s", exeU);
    else vault_default_path(vaultPath, sizeof vaultPath);
    creating = !vault_exists(vaultPath);

    fUi = CreateFontW(-15, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
    fTitle = CreateFontW(-26, 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
    fBig = CreateFontW(-28, 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Consolas");
    fMono = CreateFontW(-15, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Consolas");

    WNDCLASSW wc = {0};
    wc.lpfnWndProc = WndProc; wc.hInstance = hi;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon = LoadIconW(hi, MAKEINTRESOURCEW(1));
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = L"WordPassVault";
    RegisterClassW(&wc);
    RECT r = {0, 0, 660, 546};
    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
    AdjustWindowRect(&r, style, FALSE);
    hMain = CreateWindowW(L"WordPassVault", L"Word Password Generator + Vault", style, CW_USEDEFAULT, CW_USEDEFAULT,
                          r.right - r.left, r.bottom - r.top, NULL, NULL, hi, NULL);
    build();
    show_page(0);
    SetTimer(hMain, TIMER_IDLE, 10000, NULL);
    ShowWindow(hMain, show);

    MSG m;
    while (GetMessageW(&m, NULL, 0, 0)) {
        if (m.message == WM_KEYDOWN && m.wParam == VK_RETURN) {
            if (m.hwnd == hLPw1 || m.hwnd == hLPw2) { do_unlock(); continue; }
            if (m.hwnd == hName || m.hwnd == hPass) { do_save(); continue; }
            if (m.hwnd == hList) { do_copy(0); continue; }
        }
        if (m.message == WM_KEYDOWN && m.wParam == VK_DELETE && m.hwnd == hList) { do_delete(); continue; }
        if (!IsDialogMessageW(hMain, &m)) { TranslateMessage(&m); DispatchMessageW(&m); }
    }
    return 0;
}
